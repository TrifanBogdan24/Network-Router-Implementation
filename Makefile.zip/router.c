#include "queue.h"
#include "lib.h"
#include "protocols.h"
#include <arpa/inet.h> // Pentru funcția inet_addr
#include <netinet/in.h> // Pentru funcția ntohs
#include <string.h> // Pentru funcția memcpy
#include <stdio.h> // Pentru funcția printf

#define ICMP_PROTOCOL 1
#define MAX_ENTRIES 1000

// Declarații pentru tipurile de mesaje ICMP
#define ICMP_TIME_EXCEEDED 11
#define ICMP_DEST_UNREACH 3
#define ICMP_NET_UNREACH 0


// Funcție pentru trimiterea unui pachet ICMP cu un text string înapoi la destinație
void send_icmp_message(uint8_t type, uint8_t code, char *data, size_t data_len, struct iphdr *ip_hdr, char *buf, int interface, size_t len) {
    // Construiește un pachet ICMP cu text string
    struct icmphdr *icmp_hdr = (struct icmphdr *)(buf + sizeof(struct iphdr));
    icmp_hdr->type = type;
    icmp_hdr->code = code;
    icmp_hdr->checksum = 0;
    memcpy(buf + sizeof(struct iphdr) + sizeof(struct icmphdr), data, data_len);

    // Calculează checksum-ul pentru pachetul ICMP
    icmp_hdr->checksum = checksum((uint16_t *)icmp_hdr, sizeof(struct icmphdr) + data_len);

    // Actualizează adresa sursă cu adresa destinație și adresa destinație cu adresa sursă
    uint32_t temp_addr = ip_hdr->saddr;
    ip_hdr->saddr = ip_hdr->daddr;
    ip_hdr->daddr = temp_addr;

    // Actualizează TTL-ul și checksum-ul pentru pachetul IP
    ip_hdr->ttl = 64;
    ip_hdr->check = 0;
    ip_hdr->check = checksum((uint16_t *)ip_hdr, sizeof(struct iphdr));

    // Trimite pachetul înapoi pe interfața primită
    printf("Sending ICMP message\n");
    //send_packet(buf, len, interface); // Comentat temporar deoarece funcția send_packet nu este definită
}

// Funcție pentru a obține adresa MAC a următorului hop folosind protocolul ARP
void resolve_next_hop_mac(uint32_t next_hop_ip, char *next_hop_mac) {
    // Aici ar trebui să fie implementată logica de rezolvare a adresei MAC folosind protocolul ARP
    // Pentru exemplul nostru, vom folosi o adresă MAC statică, dar în practică ar trebui să fie utilizat protocolul ARP pentru a obține adresa MAC a următorului hop
    // În această implementare, vom folosi o adresă MAC statică pentru exemplificare
    strcpy(next_hop_mac, "00:11:22:33:44:55");
}

// IPv4 packet processing function
void process_ipv4_packet(char *buf, int interface, size_t len, const char *routing_table_file) {
    struct iphdr *ip_hdr = (struct iphdr *)buf;
    
    // Check if the packet is destined for the router
    char *router_ip = get_interface_ip(interface);
    if (ip_hdr->daddr != inet_addr(router_ip)) {
        // Packet is not destined for the router
        return;
    }

	if (ip_hdr->protocol == ICMP_PROTOCOL) {
		// Handle ICMP message
		// (to be implemented based on specific requirements)
		// Here you can handle various types of ICMP messages
		printf("ICMP packet\n");
	}
    
    // Check IPv4 packet checksum
    uint16_t ip_checksum = ip_hdr->check;
    ip_hdr->check = 0;
    if (ip_checksum != checksum((uint16_t *)ip_hdr, sizeof(struct iphdr))) {
        // Checksum does not match, discard the packet
        return;
    }
    
    // Check TTL of the packet
    if (ip_hdr->ttl <= 0) {
        // TTL expired, send ICMP "Time exceeded" message and discard the packet
        char time_exceeded_msg[] = "Time exceeded";
        // send_icmp_message(ICMP_TIME_EXCEEDED, 0, time_exceeded_msg, sizeof(time_exceeded_msg), ip_hdr, buf, interface, len);
        return;
    }
    
    // Decrement TTL
    ip_hdr->ttl--;

    // Look up in the routing table to determine next hop address and corresponding interface
    struct route_table_entry route_entry[MAX_ENTRIES];
   
    // Extrage numele fișierului de rutare din argv[1] din main
    FILE *file = fopen(routing_table_file, "r");
    if (file == NULL) {
        perror("Error opening routing table file");
        return;
    }

    int num_entries = 0;

    while (!feof(file)) {
        fscanf(file, "%x", &route_entry[num_entries].prefix);
        fscanf(file, "%x", &route_entry[num_entries].next_hop);
        fscanf(file, "%x", &route_entry[num_entries].mask);
        fscanf(file, "%d", &route_entry[num_entries].interface);

        num_entries++;
    }

    fclose(file);

    int next_hop_index = -1;
    for (int i = 0; i < num_entries; i++) {
        if ((ip_hdr->daddr & route_entry[i].mask) == (route_entry[i].prefix & route_entry[i].mask)) {
            next_hop_index = i;
            break;
        }
    }
    if (next_hop_index == -1) {
        // No route found, send ICMP "Destination unreachable" message and discard the packet
        char dest_unreachable_msg[] = "Destination unreachable";
        // send_icmp_message(ICMP_DEST_UNREACH, ICMP_NET_UNREACH, dest_unreachable_msg, sizeof(dest_unreachable_msg), ip_hdr, buf, interface, len);
        return;
    }
    
    // Update destination IP address with next hop address
    ip_hdr->daddr = route_entry[next_hop_index].next_hop;
    
    // Update IPv4 packet checksum
    ip_hdr->check = 0;
    ip_hdr->check = checksum((uint16_t *)ip_hdr, sizeof(struct iphdr));
    
    // Rewrite level 2 addresses
    // (to be implemented using ARP protocol to determine MAC address of next hop)
    char next_hop_mac[18]; // Adresa MAC are o lungime de 17 caractere + terminatorul NULL
    resolve_next_hop_mac(route_entry[next_hop_index].next_hop, next_hop_mac);
    
    // Rescrie adresele MAC
    struct ether_header *eth_hdr = (struct ether_header *)buf;
	strcpy((char*)eth_hdr->ether_shost, "00:AA:BB:CC:DD:EE");
	strcpy((char*)eth_hdr->ether_dhost, next_hop_mac);
    
    // Trimite pachetul pe interfața corespunzătoare următorului hop
    printf("Sending packet to next hop\n");
    //send_packet(buf, len, route_entry[next_hop_index].interface); // Comentat temporar deoarece funcția send_packet nu este definită
}

int main(int argc, char *argv[]) {
    char buf[MAX_PACKET_LEN];

    // Do not modify this line
    init(argc - 2, argv + 2);

    // Verifică dacă există suficiente argumente de linie de comandă
    if (argc < 2) {
        printf("Usage: %s routing_table_file\n", argv[0]);
        return 1;
    }

    const char *routing_table_file = argv[1];

    while (1) {
        int interface;
        size_t len;

        interface = recv_from_any_link(buf, &len);
        DIE(interface < 0, "recv_from_any_links");

        // IPv4 packet
        process_ipv4_packet(buf + sizeof(struct ether_header), interface, len - sizeof(struct ether_header), routing_table_file);
    }

    return 0;
}
